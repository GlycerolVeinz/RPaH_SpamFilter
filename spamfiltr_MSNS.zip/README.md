# RPaH_SpamFilter

Team work for B4B33RPH, spamfilter

We have made a simple spam-filter code. 
Based on pre-determined spam words, it searches a mail body,
and tags it based on what it found (no spam-words = ham, and vice versa). 

team:
Matvej Safrankov (saframa9)
Nadzeya Shchahlova (shchanad)

